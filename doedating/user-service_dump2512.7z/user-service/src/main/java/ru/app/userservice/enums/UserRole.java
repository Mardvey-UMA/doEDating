package ru.app.userservice.enums;

public enum UserRole {
    USER,
    ADMIN
}
