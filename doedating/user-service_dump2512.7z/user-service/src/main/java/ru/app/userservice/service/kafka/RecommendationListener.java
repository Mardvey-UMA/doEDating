package ru.app.userservice.service.kafka;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Sinks;
import reactor.core.publisher.Flux;
import ru.app.userservice.dto.RecommendationResponseDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class RecommendationListener {
    private final Logger logger = LoggerFactory.getLogger(RecommendationListener.class);
    private final Sinks.Many<RecommendationResponseDTO> recommendationsSink = Sinks.many().multicast().onBackpressureBuffer();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = "recommendation-response", groupId = "recommendation-group")
    public void listenToKafka(String message) {
        logger.info("Сообщение из kafka");

        try {
            RecommendationResponseDTO response = objectMapper.readValue(message, RecommendationResponseDTO.class);

            recommendationsSink.asFlux()
                    .doOnSubscribe(subscription -> logger.info("Новый подсисчик"))
                    .doOnTerminate(() -> logger.info("Подписка закончена"));

            var result = recommendationsSink.tryEmitNext(response);
            if (result.isFailure()) {
                logger.error("Ошибка отправка сообщения в поток: {}", result);
            }
        } catch (JsonProcessingException e) {
            logger.error("Ошибка десериализации: {}", message, e);
        }
    }

    public Flux<RecommendationResponseDTO> getRecommendationsStream(Long userId) {
        return recommendationsSink.asFlux()
                .onBackpressureBuffer()
                .doOnSubscribe(subscription -> logger.info("Клиент подписался на поток (рек сервис): {}", userId))
                .filter(response -> response.getUserId().equals(userId))
                .doOnError(e -> logger.error("Ошибка потока (рек сервис)", e));
    }
}
