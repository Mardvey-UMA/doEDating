package ru.app.userservice.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Flux;
import ru.app.userservice.dto.RecommendationResponseDTO;
import ru.app.userservice.dto.UserResponseDTO;
import ru.app.userservice.service.RecommendationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.app.userservice.service.kafka.RecommendationListener;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/recommendation")
public class RecommendationController {
    private final Logger logger = LoggerFactory.getLogger(RecommendationController.class);
    private final RecommendationService recommendationService;

    @PostMapping()
    public Mono<Void> postRecommendation(@RequestHeader(value = "X-User-ID", required = false) Long userId) {
        return recommendationService.startCalculation(userId);
    }

    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<RecommendationResponseDTO> streamRecommendations(@RequestHeader(value = "X-User-ID", required = false) Long userId) {
        return recommendationService.getRecommendationStream(userId)
                .doOnSubscribe(subscription -> logger.info("Клиент подписался на поток: {}", userId));
    }
}

