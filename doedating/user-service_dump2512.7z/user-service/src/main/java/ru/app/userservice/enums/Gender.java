package ru.app.userservice.enums;

public enum Gender {
    MALE,
    FEMALE
}
