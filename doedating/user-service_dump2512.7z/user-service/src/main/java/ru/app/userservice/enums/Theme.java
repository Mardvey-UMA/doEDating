package ru.app.userservice.enums;

public enum Theme {
    light,
    dark,
    cake
}
