package ru.app.userservice.enums;

public enum Provider {
    VK,
    PASSWORD
}
